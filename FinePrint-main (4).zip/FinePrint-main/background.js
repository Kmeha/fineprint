// background service worker (minimal)
chrome.runtime.onInstalled.addListener(() => {
  console.log("FinePrint installed.");
});
